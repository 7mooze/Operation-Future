package Scenes;

public class SaharaDesert extends Location {

}
