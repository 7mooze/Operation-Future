package Scenes;

public class Antarctica extends Location {

}
