package Scenes;

public class NightCity extends Location{

}
