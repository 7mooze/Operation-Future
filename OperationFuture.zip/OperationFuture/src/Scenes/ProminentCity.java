package Scenes;

public class ProminentCity extends Location {

}
