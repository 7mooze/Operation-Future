package Scenes;

public class HiddenLocation extends Location {

}
