package Scenes;

public class PacificOcean extends Location {

}
