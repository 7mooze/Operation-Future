package Characters;

public class General extends Character {

	@Override
	public void talk() {
		// TODO Auto-generated method stub

	}

}
