package Characters;

public abstract class Character {
	
	public String name;
	public abstract void talk();

}
