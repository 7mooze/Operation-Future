package Characters;

public class FinalBoss extends Alien {

}
