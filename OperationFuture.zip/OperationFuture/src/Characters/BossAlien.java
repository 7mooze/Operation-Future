package Characters;

public class BossAlien extends Alien {

}
