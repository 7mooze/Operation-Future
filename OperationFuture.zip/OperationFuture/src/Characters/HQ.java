package Characters;

public class HQ extends Character {

	@Override
	public void talk() {
		// TODO Auto-generated method stub

	}

}
