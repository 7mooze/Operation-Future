package Characters;

public class SoliderAlien extends Alien {

}
