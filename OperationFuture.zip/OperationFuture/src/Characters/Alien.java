package Characters;

public class Alien {

}
