package Objects;

public class Thrusters extends Object {

	@Override
	public void use() {
		// TODO Auto-generated method stub

	}

}
