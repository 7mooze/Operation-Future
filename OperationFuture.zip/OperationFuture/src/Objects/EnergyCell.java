package Objects;

public class EnergyCell extends Object {

	@Override
	public void use() {
		// TODO Auto-generated method stub

	}

}
