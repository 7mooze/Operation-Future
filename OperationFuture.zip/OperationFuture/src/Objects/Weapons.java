package Objects;

public class Weapons extends Object {

	@Override
	public void use() {
		// TODO Auto-generated method stub

	}

}
