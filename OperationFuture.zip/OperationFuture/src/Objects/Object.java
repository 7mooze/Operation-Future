package Objects;

public abstract class Object {
	
	public String name;
	
	public abstract void use();
}
