package Objects;

public class Armor extends Object {

	@Override
	public void use() {
		// TODO Auto-generated method stub

	}

}
